public interface ProjetoFreelancer {
    public void curtirProjetoFreelancer();
    public void naoCurtirProjetoFreelancer();
}
