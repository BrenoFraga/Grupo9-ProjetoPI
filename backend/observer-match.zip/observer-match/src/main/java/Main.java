import models.Freelancer;
import models.Project;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Notification f = new Notification();

        Freelancer f1 = new Freelancer("breno",1);
        Freelancer f2 = new Freelancer("isabella",2);
        Freelancer f3 = new Freelancer("gerson",3);
        Freelancer f4 = new Freelancer("Gabriel",4);

        Project p1 = new Project("malemobi trademap",10);
        Project p2 = new Project("sptech sprint",11);
        Project p3 = new Project("sptech site institucional",12);
        Project p4 = new Project("Safra corretora",13);

        List<Project> projetos = new ArrayList();
        List<Freelancer> freelancers = new ArrayList();
        List<Project> pCurtidos = new ArrayList();
        List<Freelancer> fCurtidos= new ArrayList();

        Scanner leitorNb = new Scanner(System.in);
        Scanner leitorLn = new Scanner(System.in);

        Boolean continuar = true;
        Like p = new Like();
        p.addObserver(f);

        projetos.add(p1);
        projetos.add(p2);
        projetos.add(p3);

        freelancers.add(f1);
        freelancers.add(f2);
        freelancers.add(f3);

        int qtdProjetos = projetos.size();
        int qtdFreelancers = freelancers.size();
        Boolean codigoV = false;
        Boolean codigoV2 = false;

        do{

            System.out.printf("Você é um contratante c ou um freelancer f ?\n");
            String tipo = leitorLn.next();


            switch (tipo){
                case "c":
                    System.out.printf("qual é o seu codigo");
                    Integer codigo = leitorNb.nextInt();
                    for(int j = 0; j < qtdProjetos;j++){
                        if(codigo == projetos.get(j).getFkProject()){
                            codigoV = true;
                        }else{
                            continuar = false;
                        }
                    }

                    if(codigoV){
                        for(int i = 0; i < qtdFreelancers;i++){
                            String fre = freelancers.get(i).getNome();
                            System.out.printf("você deseja curti o freelancer %s sim s ou não n?\n",fre);
                            String result = leitorLn.next();
                            switch (result){
                                case "s":{
                                    p.curtirProjetoFreelancer();
                                    fCurtidos.add(freelancers.get(i));
                                    break;
                                }
                                case "n":{
                                    p.naoCurtirProjetoFreelancer();
                                    break;
                                }
                                default:
                                    System.out.printf("valor inválido\n");
                                    break;
                            }
                        }
                        System.out.printf("\n------Freelancers curtidos ------\n");
                        for(int j = 0;j <fCurtidos.size();j++){
                            System.out.printf("%s\n",fCurtidos.get(j).getNome());
                        }
                        continuar = false;
                        break;
                    }else {
                        System.out.printf("codigo invalido\n");
                        continuar = false;
                        break;
                    }

                case "f":
                    System.out.printf("qual é o seu codigo\n");
                    Integer codigo2 = leitorNb.nextInt();
                    for(int j = 0; j < qtdFreelancers;j++){
                        if(codigo2 == freelancers.get(j).getFkF()){
                            codigoV2 = true;
                        }else{
                            continuar = false;
                        }
                    }
                  if(codigoV2){
                      for(int i = 0; i < qtdFreelancers;i++){
                          String pro = projetos.get(i).getNome();
                          System.out.printf("você deseja curti o projeto %s sim s ou não n?\n",pro);
                          String result = leitorLn.next();
                          switch (result){
                              case "s":{
                                  p.curtirProjetoFreelancer();
                                  pCurtidos.add(projetos.get(i));
                                  break;

                              }
                              case "n":{
                                  p.naoCurtirProjetoFreelancer();
                                  break;
                              }
                              default:
                                  System.out.printf("valor inválido\n");
                                  break;
                          }

                      }
                      System.out.printf("\n------Projetos curtidos ------\n");
                      for(int j = 0;j <pCurtidos.size();j++){
                          System.out.printf("%s\n",pCurtidos.get(j).getNome());
                      }
                      continuar = false;
                      break;
                  }else{
                      System.out.printf("codigo invalido");
                      continuar = false;
                      break;
                  }

                default:
                    System.out.printf("Valor inválido tente novamente\n");
                    break;

            }

            System.out.printf("\n\nDeseja entrar em outra conta s para sim e n para não\n ?");
            String rs = leitorLn.next();
            if(rs.equals("s")){
                continuar = true;
            }else{
                continuar = false;
            }

        }while (continuar);

        if(qtdFreelancers < freelancers.size() || qtdProjetos < projetos.size()){
            continuar = true;
        }



        }




    }


