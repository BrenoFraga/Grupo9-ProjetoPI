package models;

public class Freelancer {
    String nome;
    Integer fkF;

    public Freelancer(String nome, Integer fkF) {
        this.nome = nome;
        this.fkF = fkF;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getFkF() {
        return fkF;
    }

    public void setFkF(int fkF) {
        this.fkF = fkF;
    }
}
