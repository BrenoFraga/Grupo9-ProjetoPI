package models;

public class Match {
    String nomeProject;
    String nomeFreelancer;

    public Match(String nomeProject, String nomeFreelancer) {
        this.nomeProject = nomeProject;
        this.nomeFreelancer = nomeFreelancer;
    }

    public String getNomeProject() {
        return nomeProject;
    }

    public void setNomeProject(String nomeProject) {
        this.nomeProject = nomeProject;
    }

    public String getNomeFreelancer() {
        return nomeFreelancer;
    }

    public void setNomeFreelancer(String nomeFreelancer) {
        this.nomeFreelancer = nomeFreelancer;
    }
}
