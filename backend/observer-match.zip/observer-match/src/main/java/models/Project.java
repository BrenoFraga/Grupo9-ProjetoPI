package models;

public class Project {
    String nome;
    Integer fkProject;

    public Project(String nome, Integer fkProject) {
        this.nome = nome;
        this.fkProject = fkProject;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getFkProject() {
        return fkProject;
    }

    public void setFkProject(int fkProject) {
        this.fkProject = fkProject;
    }
}
