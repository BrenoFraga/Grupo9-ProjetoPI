import java.util.Observable;

public class Like extends Observable implements ProjetoFreelancer {
    String curtir = "";

    @Override
    public void curtirProjetoFreelancer() {
        //adicionar no bd que curtiu
        System.out.printf("curtiu\n");
        curtir = "s";
        try { Thread.sleep (3000); } catch (InterruptedException ex) {}
        this.mudaEstado();

    }

    @Override
    public void naoCurtirProjetoFreelancer() {
        //adicionar no bd que nao curtiu
        System.out.printf("não curtiu\n");
        curtir = "n";
        try { Thread.sleep (3000); } catch (InterruptedException ex) {}
        this.mudaEstado();

    }
    public void mudaEstado(){

        setChanged();
        notifyObservers(curtir);

    }

}
