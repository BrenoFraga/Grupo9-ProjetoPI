import java.util.Observable;
import java.util.Observer;

public class Notification implements Observer {

    public void curtirProjetoFreelancer() {
        //setar no banco que curtiu o projeto
        System.out.printf("----------Notificação--------------\n");
        System.out.printf("-----NOTIFICAÇÃO DE CURTIDA-----\n");
        System.out.printf("----------Notificação--------------\n");

    }


    public void naoCurtirProjetoFreelancer() {
        //setar no banco que nao curtiu o projeto
        System.out.printf("----------Notificação--------------\n");
        System.out.printf("-----NOTIFICAÇÃO DE CURTIDA-----\n");
        System.out.printf("----------Notificação--------------\n");
    }

    @Override
    public void update(Observable o, Object arg) {
            Like projeto = (Like) o;
            String curtir = String.valueOf(arg);

            if(curtir.equals("s")){
               this.curtirProjetoFreelancer();
            }else {
                this.naoCurtirProjetoFreelancer();
            }
    }
}
